// Get the like and dislike buttons, the like count element, and the comment form
const likeBtn = document.getElementById("like-btn");
const dislikeBtn = document.getElementById("dislike-btn");
const likeCount = document.querySelector(".like-count");
const commentForm = document.querySelector(".comment-form");

// Initial like count and liked status
let likes = 442;
let liked = false;

// Event listener for the like button
likeBtn.addEventListener("click", () => {
    if (!liked) {
        likes++;
        liked = true;
        updateLikeCount();
        likeBtn.style.backgroundColor = "black";
        likeBtn.style.color = "white";
        dislikeBtn.style.backgroundColor = "white";
        dislikeBtn.style.color = "black";
    }
});

// Event listener for the dislike button
dislikeBtn.addEventListener("click", () => {
    if (liked) {
        likes--;
        liked = false;
        updateLikeCount();
        dislikeBtn.style.backgroundColor = "black";
        dislikeBtn.style.color = "white";
        likeBtn.style.backgroundColor = "white";
        likeBtn.style.color = "black";
    }
});

// Function to update the like count text
function updateLikeCount() {
    likeCount.textContent = `${likes} likes`;
}

// Event listener for submitting a comment
commentForm.addEventListener("submit", (event) => {
    event.preventDefault(); // Prevent the default form submission
    const commentInput = commentForm.querySelector("input[type='text']");
    const commentText = commentInput.value.trim();
    if (commentText !== "") {
        addComment(commentText);
        commentInput.value = ""; // Clear the input field after posting
    }
});

// Function to add a new comment
function addComment(commentText) {
    const commentsSection = document.querySelector(".comments-section");
    const newComment = document.createElement("div");
    newComment.classList.add("comment");
    newComment.innerHTML = `
        <p class="comment-author">You:</p>
        <p class="comment-text">${commentText}</p>
    `;
    commentsSection.insertBefore(newComment, commentForm);
}
